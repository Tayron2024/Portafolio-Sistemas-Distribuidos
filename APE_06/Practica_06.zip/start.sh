#!/bin/bash
# Script de inicio rápido para Fleet Monitor

echo "=== Fleet Monitor - Inicio Rápido ==="

# 1. Verificar Docker
if ! command -v docker &> /dev/null; then
    echo "ERROR: Docker no está instalado"
    exit 1
fi

# 2. Levantar RabbitMQ
echo "1. Levantando RabbitMQ..."
docker compose -f docker-compose-rabbitmq.yml up -d

# 3. Esperar a que RabbitMQ esté listo
echo "2. Esperando a RabbitMQ..."
sleep 5

# 4. Compilar y ejecutar
echo "3. Compilando proyecto..."
mvn clean package -DskipTests -q

echo "4. Iniciando aplicación Spring Boot..."
java -jar target/fleet-monitor-1.0.0-SNAPSHOT.jar &

# 5. Verificar
sleep 8
echo "5. Verificando endpoints..."
curl -s http://localhost:8080/api/fleet/status | jq . 2>/dev/null || curl -s http://localhost:8080/api/fleet/status

echo ""
echo "=== Listo ==="
echo "API Status:     http://localhost:8080/api/fleet/status"
echo "API Telemetría: http://localhost:8080/api/fleet/vehicle/VH-001/telemetria"
echo "RabbitMQ UI:    http://localhost:15672 (admin/admin123)"
echo "H2 Console:     http://localhost:8080/h2-console (jdbc:h2:mem:fleetdb, sa, sin password)"