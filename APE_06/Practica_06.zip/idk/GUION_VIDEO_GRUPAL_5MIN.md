# GUION 1: PRESENTACIÓN GRUPAL - 5 MINUTOS
**Proyecto:** Microservicios Flota Logística con RabbitMQ y Spring Boot  
**Formato:** 3 personas, ~1:40 min cada una

---

## [0:00-0:30] INTRO GENERAL — **TODOS / UNO HABLA**

> "Presentamos la **Práctica 6 Parte 2: Microservicios con RabbitMQ y Spring Boot**.
>
> Implementamos una arquitectura de microservicios que consume colas de RabbitMQ generadas en la Parte 1 (sensores IoT → MQTT → Bridge → RabbitMQ). Nuestra app Spring Boot hace tres cosas:
> 1. **Consume telemetría GPS** de vehículos y la procesa
> 2. **Consume alertas** de temperatura y combustible, y las centraliza en una cola de notificaciones
> 3. **Expone API REST** para consultar el estado de la flota
>
> Stack: Spring Boot 3.2, Spring AMQP, RabbitMQ, Java 17, H2, Maven."

---

## [0:30-2:10] PARTE 1: CONSUMIDOR GPS — **PERSONA 1**

### Archivos a abrir:
- `src/main/java/com/fleet/monitor/config/RabbitMQConfig.java` (líneas 9, 20-23, 40-43)
- `src/main/java/com/fleet/monitor/consumer/GpsConsumer.java` (completo)
- `src/main/java/com/fleet/monitor/model/GpsMessage.java` (completo)
- Terminal con la app corriendo (logs)
- RabbitMQ UI: http://localhost:15672 → Queues → `cola.gps.telemetria`

### Qué decir + mostrar:

> "[MUESTRA RabbitMQConfig.java líneas 9, 20-23, 40-43]"
> "En **RabbitMQConfig** definimos el **Direct Exchange** `exchange.fleet` y la cola **durable** `cola.gps.telemetria` con binding `gps.routing`. Las colas son *durable=true* para que sobrevivan a reinicios del broker."

> "[MUESTRA GpsConsumer.java]"
> "El **GpsConsumer** usa `@RabbitListener(queues = GPS_QUEUE)` para escuchar esa cola. Recibe el mensaje como String (JSON), lo loggea y está preparado para persistir con JPA. Actualmente solo loggea; el almacenamiento en H2 se haría inyectando un `GpsMessageRepository` y llamando `repository.save(gps)` tras deserializar con `ObjectMapper`."

> "[MUESTRA GpsMessage.java]"
> "El modelo **GpsMessage** mapea los campos del JSON: vehicleId, timestamp, lat, lng, speed. Para JPA solo faltaría agregar `@Entity`, `@Id`, `@GeneratedValue`."

> "[CAMBIA A TERMINAL - logs de la app]"
> "En la consola vemos los mensajes llegando:"
> ```
> GPS recibido: {"vehicleId":"VH-001","lat":-0.1234,"lng":-78.4567,"speed":60}
> GPS recibido: {"vehicleId":"VH-002","lat":-0.5555,"lng":-78.9999,"speed":45}
> ```

> "[OPCIONAL: RabbitMQ UI → cola.gps.telemetria → Get Messages]"
> "En la UI de RabbitMQ confirmamos que los mensajes se enrutan correctamente a esta cola."

---

## [2:10-3:50] PARTE 2: SERVICIO ALERTAS Y NOTIFICACIONES — **PERSONA 2**

### Archivos a abrir:
- `src/main/java/com/fleet/monitor/config/RabbitMQConfig.java` (líneas 10-11, 25-33, 45-53)
- `src/main/java/com/fleet/monitor/consumer/AlertConsumer.java` (completo)
- RabbitMQ UI: Queues → `cola.alertas.temperatura`, `cola.combustible.nivel`, `cola.notificaciones`

### Qué decir + mostrar:

> "[MUESTRA RabbitMQConfig.java líneas 10-11, 25-33, 45-53]"
> "Dos colas más para alertas: `cola.alertas.temperatura` (routing key `temp.alert`) y `cola.combustible.nivel` (routing key `fuel.routing`). Ambas *durable*. Y una cuarta cola centralizada: `cola.notificaciones`."

> "[MUESTRA AlertConsumer.java]"
> "El **AlertConsumer** tiene **dos `@RabbitListener`**: uno para temperatura, otro para combustible. Ambos inyectan `RabbitTemplate` y reenvían el mensaje a `cola.notificaciones` con `convertAndSend()`. Esto es patrón **fan-in**: centralizamos alertas para que un solo consumidor downstream (email, Slack, SMS) lea una sola cola."

> "[RABBITMQ UI → Queues → cola.notificaciones]"
> "En la UI vemos que al publicar alertas en sus colas originales, aparecen también en `cola.notificaciones` —confirmando el reenvío."

> "[TERMINAL - logs]"
> "En consola vemos los warns:"
> ```
> ALERTA TEMPERATURA: {"vehicleId":"VH-001","alertType":"TEMPERATURA","value":85}
> ALERTA COMBUSTIBLE: {"vehicleId":"VH-002","alertType":"COMBUSTIBLE","value":5}
> ```

---

## [3:50-5:00] PARTE 3: API REST CONSULTA — **PERSONA 3**

### Archivos a abrir:
- `src/main/java/com/fleet/monitor/controller/FleetController.java` (completo)
- Terminal (curl) o Postman / Navegador
- Opcional: H2 Console http://localhost:8080/h2-console

### Qué decir + mostrar:

> "[MUESTRA FleetController.java]"
> "El **FleetController** expone dos endpoints GET:"
> - `GET /api/fleet/status` → resumen: total vehículos, alertas activas, timestamp
> - `GET /api/fleet/vehicle/{id}/telemetria` → datos de un vehículo específico

> "[EJECUTA EN TERMINAL]"
> ```bash
> curl http://localhost:8080/api/fleet/status
> # {"totalVehicles":3,"activeAlerts":2,"timestamp":"2026-11-08T..."}
>
> curl http://localhost:8080/api/fleet/vehicle/VH-001/telemetria
> # ["Datos de telemetria para VH-001"]
> ```

> "La API responde JSON válido. En producción el endpoint de telemetría consultaría la base H2 vía repository. La consola H2 está disponible en `/h2-console` (JDBC: `jdbc:h2:mem:fleetdb`, user: `sa`)."

> "Con esto cerramos el flujo end-to-end: **Sensores → MQTT → Bridge → RabbitMQ → Microservicios Spring Boot → API REST → Frontend**."

---

## NOTAS PARA GRABAR
- Cada persona graba su segmento (1:40 c/u) → unen en editor
- Tener archivos abiertos en pestañas antes de grabar
- App corriendo (`./start.sh`), RabbitMQ UI logueada
- Terminal lista con curls en historial