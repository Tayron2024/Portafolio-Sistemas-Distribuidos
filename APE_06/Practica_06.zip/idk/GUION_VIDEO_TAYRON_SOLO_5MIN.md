# GUION 2: PRESENTACIÓN INDIVIDUAL (TAYRON MORALES) - 5 MINUTOS
**Proyecto:** Microservicios Flota Logística con RabbitMQ y Spring Boot  
**Formato:** Una persona presenta TODO en 5 min

---

## PREPARACIÓN ANTES DE GRABAR
```bash
cd /home/tayronfmv/Documentos/SistemasDistribuidos/Ape6/Ape6_Parte2/practica_06
./start.sh   # levanta RabbitMQ + app
# Verificar: app corriendo en puerto 8080, RabbitMQ UI en 15672
```

**Pestañas abiertas en editor:**
1. `RabbitMQConfig.java`
2. `GpsConsumer.java`
3. `GpsMessage.java`
4. `AlertConsumer.java`
5. `FleetController.java`

**Navegador:**
- RabbitMQ UI: http://localhost:15672 (admin/admin123) → pestaña Queues
- Terminal lista con curls

---

## [0:00-0:40] INTRO GENERAL

> "Hola, soy **Tayron Morales**. Presento la **Práctica 6 Parte 2: Microservicios con RabbitMQ y Spring Boot**.
>
> Esta práctica implementa la capa de microservicios que consume los mensajes de RabbitMQ —que vienen de la Parte 1 (sensores IoT → MQTT → Bridge Python)— y los procesa en tres frentes:
> 1. **Telemetría GPS**: recibe posiciones de vehículos, loggea y está listo para persistir en H2
> 2. **Alertas y notificaciones**: consume temperatura y combustible, y centraliza todo en una cola de notificaciones
> 3. **API REST**: expone endpoints para consultar estado de flota y telemetría por vehículo
>
> Stack: Spring Boot 3.2, Spring AMQP, RabbitMQ, Java 17, H2, Maven. Todo corre en un JAR de 48 MB."

---

## [0:40-1:50] 1. ARQUITECTURA RABBITMQ + CONSUMIDOR GPS

### Archivos: `RabbitMQConfig.java` + `GpsConsumer.java` + `GpsMessage.java` + Terminal + RabbitMQ UI

> "[ABRE RabbitMQConfig.java — SEÑALA líneas 9, 13, 20-23, 40-43]"
> "Empecemos por la configuración. En **RabbitMQConfig** declaramos un **Direct Exchange** llamado `exchange.fleet`. El Direct Exchange enruta por **coincidencia exacta** de routing key.
>
> Creamos 4 colas **durable=true** —sobreviven a reinicios del broker—:
> - `cola.gps.telemetria` → binding `gps.routing`
> - `cola.alertas.temperatura` → `temp.alert`
> - `cola.combustible.nivel` → `fuel.routing`
> - `cola.notificaciones` → centralizada para alertas"

> "[ABRE GpsConsumer.java — RECORRE TODO]"
> "El **GpsConsumer** es simple: `@RabbitListener(queues = GPS_QUEUE)` escucha `cola.gps.telemetria`. Recibe el mensaje como String (JSON crudo), lo loggea con `log.info()` y tiene try-catch. **Nota**: el PDF pide almacenar en BD; actualmente solo loggea. Para persistir en H2 vía JPA inyectaríamos un `GpsMessageRepository`, deserializaríamos con `ObjectMapper.readValue(json, GpsMessage.class)` y haríamos `repository.save(gps)`."

> "[ABRE GpsMessage.java — SEÑALA CAMPOS]"
> "El modelo **GpsMessage** mapea: vehicleId, timestamp, lat, lng, speed. Para JPA solo falta `@Entity`, `@Id`, `@GeneratedValue`."

> "[TERMINAL — MUESTRA LOGS]"
> "Publico un GPS de prueba desde RabbitMQ UI… y en consola aparece:"
> ```
> GPS recibido: {"vehicleId":"VH-001","lat":-0.1234,"lng":-78.4567,"speed":60}
> ```

> "[RABBITMQ UI — QUEUES → cola.gps.telemetria]"
> "En la UI confirmamos: mensaje encolado, routing key `gps.routing`, consumidor activo."

---

## [1:50-3:30] 2. SERVICIO ALERTAS + FAN-IN A NOTIFICACIONES

### Archivos: `RabbitMQConfig.java` (colas alertas) + `AlertConsumer.java` + RabbitMQ UI

> "[RabbitMQConfig.java — LÍNEAS 10-11, 25-33, 45-53]"
> "Dos colas para alertas: `cola.alertas.temperatura` (routing `temp.alert`) y `cola.combustible.nivel` (routing `fuel.routing`). Ambas durable."

> "[AlertConsumer.java — RECORRE COMPLETO]"
> "El **AlertConsumer** es clave: tiene **dos `@RabbitListener`** en una misma clase —uno para temperatura, otro para combustible—. Inyecta `RabbitTemplate` y **ambos reenvían a `cola.notificaciones`** con `rabbitTemplate.convertAndSend(NOTIFICATION_QUEUE, message)`.
>
> Esto es patrón **fan-in** (o *message aggregation*): centralizamos alertas de múltiples orígenes en **una sola cola**. Así un consumidor downstream (notificador email, Slack, SMS) solo suscribe a una cola en vez de tres."

> "[RABBITMQ UI — QUEUES → cola.notificaciones]"
> "Publico una alerta de temperatura… y vemos que aparece en su cola original **y** en `cola.notificaciones`. Lo mismo con combustible. El reenvío funciona."

> "[TERMINAL — LOGS]"
> "En consola vemos los warns diferenciados:"
> ```
> ALERTA TEMPERATURA: {"vehicleId":"VH-001","alertType":"TEMPERATURA","value":85}
> ALERTA COMBUSTIBLE: {"vehicleId":"VH-002","alertType":"COMBUSTIBLE","value":5}
> ```

---

## [3:30-4:40] 3. API REST CONSULTA FLOTA

### Archivos: `FleetController.java` + Terminal (curl) + H2 Console (opcional)

> "[FleetController.java — RECORRE LOS DOS ENDPOINTS]"
> "El **FleetController** expone dos GETs simples:
> - `/api/fleet/status` → resumen global: totalVehicles, activeAlerts, timestamp
> - `/api/fleet/vehicle/{id}/telemetria` → telemetría de un vehículo"

> "[TERMINAL — EJECUTA CURLS]"
> ```bash
> curl http://localhost:8080/api/fleet/status
> # {"totalVehicles":3,"activeAlerts":2,"timestamp":"2026-11-08T..."}
>
> curl http://localhost:8080/api/fleet/vehicle/VH-001/telemetria
> # ["Datos de telemetria para VH-001"]
> ```

> "La API responde JSON válido. En producción el segundo endpoint haría `repository.findByVehicleId(id)`. La base H2 en memoria está accesible en `/h2-console` (JDBC `jdbc:h2:mem:fleetdb`, user `sa`, sin password)."

---

## [4:40-5:00] CIERRE

> "Resumen del flujo completo:
> **Sensores IoT → MQTT (Parte 1) → Bridge Python → RabbitMQ (exchange.fleet) →**
> - **GpsConsumer** → procesa GPS → (persistencia H2 pendiente)
> - **AlertConsumer** → temp + combustible → **fan-in** → cola.notificaciones
> - **FleetController** → API REST para frontend
>
> Código listo para integrar con la Parte 1. ¿Preguntas? Gracias."

---

## CHECKLIST RÁPIDO GRABACIÓN
- [ ] App corriendo (`./start.sh` ejecutado, PID vivo)
- [ ] 5 pestañas editor abiertas en orden
- [ ] RabbitMQ UI logueada en pestaña Queues
- [ ] Terminal con historial: `curl status`, `curl telemetria`
- [ ] Grabas en un solo take (5 min) o 4 segmentos (intro + 3 partes) y unes
- [ ] Zoom en código cuando señales líneas; terminal legible (font size 14+)