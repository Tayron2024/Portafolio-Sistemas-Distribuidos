# Fleet Monitor - Microservicios con RabbitMQ y Spring Boot

## Estructura del Proyecto
```
practica/
├── pom.xml
├── docker-compose-rabbitmq.yml
├── src/main/
│   ├── java/com/fleet/monitor/
│   │   ├── FleetMonitorApplication.java
│   │   ├── config/RabbitMQConfig.java
│   │   ├── model/GpsMessage.java
│   │   ├── consumer/GpsConsumer.java
│   │   ├── consumer/AlertConsumer.java
│   │   └── controller/FleetController.java
│   └── resources/application.properties
```

## Requisitos
- Java 25 (latest LTS)
- Maven 3.8+
- Docker y Docker Compose

## Instrucciones de Ejecución

### 1. Levantar RabbitMQ
```bash
cd /home/tayronfmv/Documentos/SistemasDistribuidos/Ape6/Ape6_Parte2
docker-compose -f docker-compose-rabbitmq.yml up -d
```
- RabbitMQ AMQP: localhost:5672
- Management UI: http://localhost:15672 (admin/admin123)

### 2. Compilar y ejecutar la aplicación Spring Boot
```bash
cd /home/tayronfmv/Documentos/SistemasDistribuidos/Ape6/Ape6_Parte2/practica
mvn spring-boot:run
```
La aplicación estará disponible en: http://localhost:8080

### 3. Probar la API REST
```bash
# Estado de la flota
curl http://localhost:8080/api/fleet/status

# Telemetría de un vehículo
curl http://localhost:8080/api/fleet/vehicle/VH-001/telemetria
```

### 4. Consola H2 Database
http://localhost:8080/h2-console
- JDBC URL: jdbc:h2:mem:fleetdb
- User: sa
- Password: (vacío)

## Colas y Exchanges Configurados
| Componente | Nombre | Tipo |
|------------|--------|------|
| Exchange | exchange.fleet | Direct |
| Queue GPS | cola.gps.telemetria | Durable |
| Queue Temp Alert | cola.alertas.temperatura | Durable |
| Queue Fuel Alert | cola.combustible.nivel | Durable |
| Queue Notifications | cola.notificaciones | Durable |

## Bindings
- `cola.gps.telemetria` → `exchange.fleet` con routing key `gps.routing`
- `cola.alertas.temperatura` → `exchange.fleet` con routing key `temp.alert`
- `cola.combustible.nivel` → `exchange.fleet` con routing key `fuel.routing`

## Flujo de Datos
1. Sensores IoT → MQTT (Parte 1)
2. Puente Python MQTT → RabbitMQ
3. RabbitMQ → Spring Boot Consumers (GpsConsumer, AlertConsumer)
4. AlertConsumer reenvía a `cola.notificaciones`
5. API REST expone estado de flota y telemetría